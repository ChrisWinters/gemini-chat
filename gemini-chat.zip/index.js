#!/usr/bin/env node
'use strict'

require('dotenv').config()
const fs = require("fs")
const path = require("path")
const archiver = require("archiver")
const inquirer = require("inquirer")
const readline = require("readline")
const { GoogleGenerativeAI } = require("@google/generative-ai")

// Maximum tokens to use for API replies.
const tokens = 500

// Test prompt for single call model.
const prompt = "Select any unique word related to Google and create a fun initialism, then explain it."

// Initialize Google Generative AI and pass in API key.
const geminiAI = new GoogleGenerativeAI(process.env.API_KEY)

// Create GenerativeModel instance for the provided model name.
const model = geminiAI.getGenerativeModel({ model: "gemini-pro"})

// Get command-line argument.
const [arg1] = process.argv.slice(2)

// Argument required.
if (!arg1 || (!arg1.includes("-t") && !arg1.includes("-l") && !arg1.includes("-z"))) {
  console.log(`\nArgument missing: npm run [command]`)
  console.log(`npm run test | Run single response test prompt.`)
  console.log(`npm run chat | Run live chat model.`)
  console.log(`npm run zip  | Zip the project.\n`)
  process.exit(0)
}

/**
 * API Key missing: Inquirer about API Key and maybe create .env file.
 */
const apiKey = async () => {
  console.log("\nEnter a Google Generative AI API Key then press enter.")
  console.log("Create API Key: https://aistudio.google.com/app/apikey\n")

  // Launch the prompt interface.
  const answer = await inquirer.prompt({
    type: "input",
    name: "api_key",
    message: "\nAPI Key >"
  })

  // If API Key was provided.
  if (answer['api_key'].length) {
    const apiKey = answer['api_key'].toString()

    // Asynchronously writes data to a file, replacing the file if it already exists.
    fs.writeFile('.env', `API_KEY=${apiKey}\nTOKENS=${tokens}`, (error) => {
      if (error) {
        console.log("\nNo action taken: Unable to create .env file.\n")
      } else {
        const command = process.env.npm_lifecycle_event
        console.log("\nCreated .env and saved API Key data.")
        console.log(`Run the command again: npm run ${command}\n`)
      }
    })
  // No API Key provided.
  } else {
    console.log("\nNo action taken: A Google Generative AI API Key is required!\n")
  }
}

/**
 * Test single call to the model.
 * Command: npm run test
 * @param {string} prompt Test prompt for single call model.
 */
const test = async (prompt) => {
  try {
    // Get GenerateContentResponse object.
    const result = await model.generateContent(prompt)
  
    // Maybe get response text and return to console log.
    if (result.response) {
      const reply = result.response.text()
  
      // Display prompt and reply.
      console.log(`\nPrompt: ${prompt}`)
      console.log(`Response: ${reply}\n`)
      process.exit(0)
    }
  } catch (error) {
    console.error("Error:", error)
    process.exit(0)
  }
}

/**
 * Hook chat session and prompt loop.
 * Command: npm run chat
 */
const chat = async () => {
  const maxTokens = (process.env.TOKENS) ? process.env.TOKENS : tokens

  // Start new ChatSession instance used for multi-turn chats.
  const chatSession = model.startChat({
    history: [],
    generationConfig: {
      maxOutputTokens: maxTokens,
    }
  })

  /**
   * Ask / response question callback loop.
   */
  const askAndRespond = async (status) => {
    if (!status) {
      console.log("\n\n ==> Type 'exit' to quit.\n")
    }

    // Creates a new readline interface instance.
    const read = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    })

    read.question("Enter a prompt > ", async (msg) => {
      // Type exit to quit.
      if (msg.toLowerCase() === "exit") {
        read.close()
        process.exit(0)
      }

      try {
        // Sends a chat message and receives a non-streaming GenerateContentResult.
        const generateResult = await chatSession.sendMessage(msg)

        // API returned safety error.
        if (generateResult.response.candidates[0].finishReason === "SAFETY") {
          console.log(`\n ==> Gemini returned a safety warning, reword the prompt and try again.\n`)
          process.exit(0)
        }

        // Maybe get response text and return to console log.
        if (generateResult.response.candidates[0].finishReason === "STOP") {
          const response = generateResult.response.text()
          console.log(`\nAI > ${response}\n`)

          // Hook callback to repeat.
          askAndRespond(true)
        }
      } catch (error) {
        console.error("Error:", error)
        process.exit(0)
      }
    })
  }

  askAndRespond(false)
}

/**
 * Create project zip file
 * Creates gemini-chat.zip in current directory
 * Command: npm run zip
 */
const zip = () => {
  const zipFile = path.resolve(__dirname,'gemini-chat.zip')
  const indexFile = path.resolve(__dirname,'index.js')
  const indexStream = fs.createReadStream(indexFile)
  const packageFile = path.resolve(__dirname,'package.json')
  const packageStream = fs.createReadStream(packageFile)
  const packageLockFile = path.resolve(__dirname,'package-lock.json')
  const packageLockStream = fs.createReadStream(packageLockFile)
  const licenseFile = path.resolve(__dirname,'LICENSE')
  const licenseStream = fs.createReadStream(licenseFile)

  // Verify index.js exists.
  indexStream.on('error', function(error) {
    if (error.code === "ENOENT") {
      console.log(`\nUnable to resolve: ${indexFile}.\n`)
      process.exit(0)
    } else {
      throw error
    }
  })

  // Verify package.json exists.
  packageStream.on('error', function(error) {
    if (error.code === "ENOENT") {
      console.log(`\nUnable to resolve: ${packageFile}.\n`)
      process.exit(0)
    } else {
      throw error
    }
  })

  // Verify package-lock.json exists.
  packageLockStream.on('error', function(error) {
    if (error.code === "ENOENT") {
      console.log(`\nUnable to resolve: ${packageLockFile}.\n`)
      process.exit(0)
    } else {
      throw error
    }
  })

  // Verify LICENSE exists.
  licenseStream.on('error', function(error) {
    if (error.code === "ENOENT") {
      console.log(`\nUnable to resolve: ${licenseFile}.\n`)
      process.exit(0)
    } else {
      throw error
    }
  })

  // Create a file to stream archive data to.
  const output = fs.createWriteStream(zipFile)
  const archive = archiver("zip", {
    zlib: { level: 9 },
  })

  /**
  // This event is fired when the data source is drained no matter what was the data source.
  // It is not part of this library but rather from the NodeJS Stream API.
  // @see: https://nodejs.org/api/stream.html#stream_event_end
  */
  output.on("end", function () {
    console.log('\nNode stream error: Data has been drained.\n')
    process.exit(0)
  })

  // Pipe archive data to the file.
  archive.pipe(output)

  // Append files from a sub-directory, putting its contents at the root of archive.
  archive.append(indexStream, { name: 'index.js' })
  archive.append(packageStream, { name: 'package.json' })
  archive.append(packageLockStream, { name: 'package-lock.json' })
  archive.append(licenseStream, { name: 'LICENSE' })

  // Stat failures and other non-blocking errors.
  archive.on("warning", function (error) {
    if (error.code === "ENOENT") {
      console.log('\nArchiver error: No such directory entry.\n')
      process.exit(0)
    } else {
      throw error
    }
  })

  // Catch error explicitly.
  archive.on("error", function (error) {
    console.error('\nArchiver error: \n', error)
    process.exit(0)
  })

  // Finished receiving and writing data.
  output.on('finish', () => {
    console.log('\nZip file created')
    console.log(`File: ${zipFile}`)
  })

  // Listen for all archive data to be written.
  // Event 'close' is fired only when a file descriptor is involved.
  output.on('close', function() {
    const bytes = archive.pointer()
    const mb = (bytes/1014)
    console.log(`Size: ${Math.round(mb * 100) / 100}mb\n`)
  })

  // Finalize the archive (ie we are done appending files but streams have to finish yet),
  // 'close', 'end' or 'finish' may be fired right after calling this method so register to them beforehand.
  archive.finalize()
}

/**
 * Init Gemini AI.
 */
const init = () => {
  // API Key Required.
  if (!process.env.API_KEY) {
    apiKey()
    return
  }

  if (arg1.includes("-t")) {
    test(prompt)
  }

  if (arg1.includes("-l")) {
    chat()
  }

  if (arg1.includes("-z")) {
    zip()
  }
}

init()
